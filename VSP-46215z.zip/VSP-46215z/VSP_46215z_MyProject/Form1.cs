﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSP_46215z_MyProject
{
    public partial class Form1 : Form
    {
    Random randomizer = new Random();

        // Променливи за събиране
        int addend1;
        int addend2;

        // Променливи за изваждане
        int minuend;
        int subtrahend;
        
        // Променливи за умножение
        int multiplicand;
        int multiplier;

        // Променливи за деление
        int dividend;
        int divisor;

        // Променлива, която проследява оставащото време в секунди 
        int timeLeft;

        // Метод за започване на задачата, 
        // дава случайни числа на всяко поле и започва часовника за обратно броене
        public void StartTheQuiz()
        {
            timeLabel.BackColor = Color.Red;

            // randomizer метод за генериране на случайни числа за събиране
            addend1 = randomizer.Next(51);
            addend2 = randomizer.Next(51);

            // добавяне на случайните числа в полетата
            plusLeftLabel.Text = addend1.ToString();
            plusRightLabel.Text = addend2.ToString();
            // Подсигурява numericUpDown методът да е винаги 0 преди да добавя числа към него
            sum.Value = 0;

            // същата процедура като при събирането, но започва от 1 защото изважда
            minuend = randomizer.Next(1, 101);
            subtrahend = randomizer.Next(1, minuend);
            minusLeftLabel.Text = minuend.ToString();
            minusRightLabel.Text = subtrahend.ToString();
            difference.Value = 0;

            // същата процедура като при събирането, но започва от 1 защото умножава
            multiplicand = randomizer.Next(2, 11);
            multiplier = randomizer.Next(2, 11);
            timesLeftLabel.Text = multiplicand.ToString();
            timesRightLabel.Text = multiplier.ToString();
            product.Value = 0;

            // същата процедура като при събирането, но започва от 1 защото дели
            divisor = randomizer.Next(2, 11);
            int temporaryQuotient = randomizer.Next(2, 11);
            dividend = divisor * temporaryQuotient;
            dividedLeftLabel.Text = dividend.ToString();
            dividedRightLabel.Text = divisor.ToString();
            quotient.Value = 0;

            // започващо време в секунди
            timeLeft = 120;
            timeLabel.Text = "2 минути";
            // часовникът стартира
            timer1.Start();
        }

        public Form1()
        {
            InitializeComponent();
        }
        // метод, който извиква startQuiz методът, започва отборяването и възпира бутонът от това да бъде натиснат
        private void startButton_Click(object sender, EventArgs e)
        {
            StartTheQuiz();
            startButton.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // проверяваме извикания метод за резултата, 
            // ако е верен/грешен часовникът спира и показва съобщение
            // ако няма отговор timeLeft променливата изважда 1 секунда на всяка 1000 милисекунда
            if(CheckTheAnswer())
            {
                timer1.Stop();
                MessageBox.Show("Успешно завърши викторината!", "Честито!");
                startButton.Enabled = true;
            }
            else if(timeLeft > 0)
            {
                timeLeft--;
                timeLabel.Text = timeLeft + " секунди";
            } else
            {
                timer1.Stop();
                timeLabel.Text = "Time's up!";
                MessageBox.Show("Не завърши викторината навреме!", "За съжеление!");
                sum.Value = addend1 + addend2;
                difference.Value = minuend - subtrahend;
                product.Value = multiplicand * multiplier;
                quotient.Value = dividend / divisor;

                startButton.Enabled = true;
            }
        }
        // Метод за проверяване на резултата от операциите, връща булева стойност вярно/грешно
        private bool CheckTheAnswer()
        {
            if((addend1 + addend2 == sum.Value)
        && (minuend - subtrahend == difference.Value)
        && (multiplicand * multiplier == product.Value)
        && (dividend / divisor == quotient.Value))
            {
                return true;
            } else
            {
                return false;
            }
        }

        private void answer_Enter(object sender, EventArgs e)
        {
            NumericUpDown answerBox = sender as NumericUpDown;

            if(answerBox != null)
            {
                int lengthOfAnswer = answerBox.Value.ToString().Length;
                answerBox.Select(0, lengthOfAnswer);
            }
        }
    }
}
