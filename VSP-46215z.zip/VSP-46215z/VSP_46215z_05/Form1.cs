﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSP_46215z_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.buttonOK.Enabled = false;

            this.textBoxAddress.Tag = false;
            this.textBoxAge.Tag = false;
            this.textBoxName.Tag = false;

            this.textBoxName.Validating += new CancelEventHandler(textBoxEmpty_Validating);
            this.textBoxAddress.Validating += new CancelEventHandler(textBoxEmpty_Validating);

        }

        private void ValidateOK()
        {
            this.buttonOK.Enabled = (
              (bool)(this.textBoxAddress.Tag) 
              && (bool)(this.textBoxName.Tag)
              && (bool)(this.textBoxAge.Tag)
            );
        }

        private void textBoxEmpty_Validating(object sender, CancelEventArgs e)
        {
            TextBox tb = (TextBox) sender;
            if(tb.Text.Length == 0)
            {
                tb.BackColor = Color.Red;
                tb.Tag = false;

            } else
            {
                tb.BackColor = System.Drawing.SystemColors.Window;
                tb.Tag = true;
            }
            ValidateOK();
        }


        private void textBoxAge_Keypress(object sender, KeyPressEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if(((tb.Text.Length == 0) && (e.KeyChar == 48)) || ((e.KeyChar < 48 && e.KeyChar > 57) && e.KeyChar != 8))
            {
                e.Handled = true;
            }
        }

        private void textBoxAge_KeyUp(object sender, KeyEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if(tb.Text.Length == 0)
            {
                if(Int16.Parse(tb.Text.ToString()) < 18)
                {
                    tb.Tag = false;
                    tb.BackColor = Color.Red;
                }
            } else
            {
                tb.Tag = true;
                tb.BackColor = SystemColors.Window;
            }
            ValidateOK();
        }

        private void textBoxAge_Validating(object sender, CancelEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if(tb.Text.Length == 0)
            {
                tb.Tag = false;
                tb.BackColor = Color.Red;
            }
            ValidateOK();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string output;
            output = $"Име: {this.textBoxName.Text}\r\n";
            output += $"Адрес: {this.textBoxAddress.Text}\r\n";
            output += $"Професия: {(string)(this.checkBoxProgrammer.Checked ? "Програмист" : "Не е програмист")}\r\n";
            output += $"Пол: {(string)(this.radioButtonMale.Checked ? "Мъж" : "Жена")}\r\n";
            output += $"Възраст: {this.textBoxAge.Text}\r\n";
            this.textBoxOutput.Text = output;
        }

        private void buttonHelp_Click(object sender, EventArgs e)
        {
            string output;
            output = "Помощна информация:\r\n\r\n";
            output += "Име = Вашето име\r\n";
            output += "Адрес = Вашеият адрес\r\n";
            output += "Професия = Вашата професия\r\n";
            output += "Възраст = Вашата вързраст\r\n";
            this.textBoxOutput.Text = output;
        }

        private void textBox_TextChanged(object sender, EventArgs e)
        {
            TextBox tb = (TextBox)sender;
            if(tb.Text.Length == 0)
            {
                tb.Tag = false;
                tb.BackColor = Color.Red;
            }  else
            {
                tb.Tag = true;
                tb.BackColor = SystemColors.Window;
            }
            ValidateOK();
        }
    }
}
