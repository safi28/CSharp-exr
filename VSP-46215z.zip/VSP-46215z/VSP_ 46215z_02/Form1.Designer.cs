﻿namespace VSP__46215z_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.okBtn = new System.Windows.Forms.Button();
            this.bgBtn = new System.Windows.Forms.Button();
            this.ukBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(311, 210);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(122, 45);
            this.okBtn.TabIndex = 1;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.okBtn_Click);
            // 
            // bgBtn
            // 
            this.bgBtn.Image = global::VSP__46215z_2.Properties.Resources.bgFlag;
            this.bgBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bgBtn.Location = new System.Drawing.Point(452, 112);
            this.bgBtn.Name = "bgBtn";
            this.bgBtn.Size = new System.Drawing.Size(138, 45);
            this.bgBtn.TabIndex = 2;
            this.bgBtn.Text = "Bulgarian";
            this.bgBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bgBtn.UseVisualStyleBackColor = true;
            this.bgBtn.Click += new System.EventHandler(this.bgBtn_Click);
            // 
            // ukBtn
            // 
            this.ukBtn.Image = global::VSP__46215z_2.Properties.Resources.Webp_net_resizeimage;
            this.ukBtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ukBtn.Location = new System.Drawing.Point(158, 112);
            this.ukBtn.Name = "ukBtn";
            this.ukBtn.Size = new System.Drawing.Size(143, 45);
            this.ukBtn.TabIndex = 0;
            this.ukBtn.Text = "English";
            this.ukBtn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ukBtn.UseVisualStyleBackColor = true;
            this.ukBtn.Click += new System.EventHandler(this.ukBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bgBtn);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.ukBtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ukBtn;
        private System.Windows.Forms.Button okBtn;
        private System.Windows.Forms.Button bgBtn;
    }
}

