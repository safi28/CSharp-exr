﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VSP_46215z_06
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonBold_Click(object sender, EventArgs e)
        {
            Font oldFont, newFont;
            oldFont = this.richTextBoxText.SelectionFont;
            newFont = oldFont.Bold ? new Font(oldFont, oldFont.Style & ~FontStyle.Bold) : new Font(oldFont, oldFont.Style | FontStyle.Bold);
            this.richTextBoxText.SelectionFont = newFont;
            this.richTextBoxText.Focus();
        }

        private void buttonUnderline_Click(object sender, EventArgs e)
        {
            Font oldFont, newFont;
            oldFont = this.richTextBoxText.SelectionFont;
            newFont = oldFont.Underline
                ? new Font(oldFont, oldFont.Style & ~FontStyle.Underline)
                : new Font(oldFont, oldFont.Style | FontStyle.Underline);
            this.richTextBoxText.SelectionFont = newFont;
            this.richTextBoxText.Focus();
        }

        private void buttonItalic_Click(object sender, EventArgs e)
        {
            Font oldFont, newFont;
            oldFont = this.richTextBoxText.SelectionFont;
            newFont = oldFont.Italic
                ? new Font(oldFont, oldFont.Style & ~FontStyle.Italic)
                : new Font(oldFont, oldFont.Style | FontStyle.Italic);
            this.richTextBoxText.SelectionFont = newFont;
            this.richTextBoxText.Focus();
        }

        private void buttonCenter_Click(object sender, EventArgs e)
        {
            if (this.richTextBoxText.SelectionAlignment == HorizontalAlignment.Center)
            {
                this.richTextBoxText.SelectionAlignment = HorizontalAlignment.Left;
            } else
            {
                this.richTextBoxText.SelectionAlignment = HorizontalAlignment.Center;
                this.richTextBoxText.Focus();
            }
        }

        private void ApplyTextSize(string textSize)
        {
            float newSize = Convert.ToSingle(textSize);
            FontFamily currentFontFamily;
            Font newFont;
            currentFontFamily = this.richTextBoxText.SelectionFont.FontFamily;
            newFont = new Font(currentFontFamily, newSize);
            this.richTextBoxText.SelectionFont = newFont;
        }
        private void textBoxSize_KeyPress(object sender, KeyPressEventArgs e)
        {
            const int minSize = 8;
            if((e.KeyChar < 48 || e.KeyChar > 57) && e.KeyChar != 13 && e.KeyChar != 8)
            {
                e.Handled = true;
            } else if(e.KeyChar == 13)
            {
                TextBox txt = (TextBox)sender;
                if(Convert.ToInt16(txt.Text) < minSize)
                {
                    txt.Text = Convert.ToString(minSize);
                }
                ApplyTextSize(txt.Text);
                e.Handled = true;
                this.richTextBoxText.Focus();
            }
            
        }
        private void richTextBoxText_LinkClicked(object sender,LinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start(e.LinkText);

        }

        private void buttonLoad_Click(object sender, EventArgs e)
        {
            try
            {
                richTextBoxText.LoadFile(MyFile);
                MessageBox.Show($"File {MyFile} is loaded!");
            } catch(System.IO.FileNotFoundException)
            {
                MessageBox.Show($"File {MyFile} is not found!");
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                this.richTextBoxText.SaveFile(MyFile);
                MessageBox.Show($"File {MyFile} is saved!");
            } catch(System.Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }
    }
}
