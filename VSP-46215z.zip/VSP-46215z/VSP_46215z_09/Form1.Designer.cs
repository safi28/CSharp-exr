﻿namespace VSP_46215z_09
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.tabPageApplications = new System.Windows.Forms.TabPage();
            this.tabPageQuestions = new System.Windows.Forms.TabPage();
            this.tabPageBrowsers = new System.Windows.Forms.TabPage();
            this.tabPageFolders = new System.Windows.Forms.TabPage();
            this.tabPageNotes = new System.Windows.Forms.TabPage();
            this.tabPageDocsOK = new System.Windows.Forms.TabPage();
            this.tabPageDocs = new System.Windows.Forms.TabPage();
            this.tabPageNewTasks = new System.Windows.Forms.TabPage();
            this.tabPageTasks = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folder.png");
            this.imageList1.Images.SetKeyName(1, "document.png");
            this.imageList1.Images.SetKeyName(2, "file.png");
            this.imageList1.Images.SetKeyName(3, "question.png");
            this.imageList1.Images.SetKeyName(4, "post-it.png");
            this.imageList1.Images.SetKeyName(5, "browser.png");
            this.imageList1.Images.SetKeyName(6, "next-button.png");
            this.imageList1.Images.SetKeyName(7, "checklist.png");
            this.imageList1.Images.SetKeyName(8, "google-docs.png");
            this.imageList1.Images.SetKeyName(9, "choice.png");
            // 
            // tabPageApplications
            // 
            this.tabPageApplications.ImageIndex = 9;
            this.tabPageApplications.Location = new System.Drawing.Point(4, 84);
            this.tabPageApplications.Name = "tabPageApplications";
            this.tabPageApplications.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageApplications.Size = new System.Drawing.Size(792, 362);
            this.tabPageApplications.TabIndex = 8;
            this.tabPageApplications.Text = "Приложения";
            this.tabPageApplications.UseVisualStyleBackColor = true;
            // 
            // tabPageQuestions
            // 
            this.tabPageQuestions.ImageIndex = 3;
            this.tabPageQuestions.Location = new System.Drawing.Point(4, 84);
            this.tabPageQuestions.Name = "tabPageQuestions";
            this.tabPageQuestions.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageQuestions.Size = new System.Drawing.Size(792, 362);
            this.tabPageQuestions.TabIndex = 7;
            this.tabPageQuestions.Text = "Въпроси";
            this.tabPageQuestions.UseVisualStyleBackColor = true;
            // 
            // tabPageBrowsers
            // 
            this.tabPageBrowsers.ImageIndex = 5;
            this.tabPageBrowsers.Location = new System.Drawing.Point(4, 84);
            this.tabPageBrowsers.Name = "tabPageBrowsers";
            this.tabPageBrowsers.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageBrowsers.Size = new System.Drawing.Size(792, 362);
            this.tabPageBrowsers.TabIndex = 6;
            this.tabPageBrowsers.Text = "Браузър";
            this.tabPageBrowsers.UseVisualStyleBackColor = true;
            // 
            // tabPageFolders
            // 
            this.tabPageFolders.ImageIndex = 0;
            this.tabPageFolders.Location = new System.Drawing.Point(4, 44);
            this.tabPageFolders.Name = "tabPageFolders";
            this.tabPageFolders.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageFolders.Size = new System.Drawing.Size(792, 402);
            this.tabPageFolders.TabIndex = 5;
            this.tabPageFolders.Text = "Папки";
            this.tabPageFolders.UseVisualStyleBackColor = true;
            // 
            // tabPageNotes
            // 
            this.tabPageNotes.ImageIndex = 4;
            this.tabPageNotes.Location = new System.Drawing.Point(4, 44);
            this.tabPageNotes.Name = "tabPageNotes";
            this.tabPageNotes.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageNotes.Size = new System.Drawing.Size(792, 402);
            this.tabPageNotes.TabIndex = 4;
            this.tabPageNotes.Text = "Бележки";
            this.tabPageNotes.UseVisualStyleBackColor = true;
            // 
            // tabPageDocsOK
            // 
            this.tabPageDocsOK.ImageIndex = 8;
            this.tabPageDocsOK.Location = new System.Drawing.Point(4, 44);
            this.tabPageDocsOK.Name = "tabPageDocsOK";
            this.tabPageDocsOK.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDocsOK.Size = new System.Drawing.Size(792, 402);
            this.tabPageDocsOK.TabIndex = 3;
            this.tabPageDocsOK.Text = "Готови документи";
            this.tabPageDocsOK.UseVisualStyleBackColor = true;
            // 
            // tabPageDocs
            // 
            this.tabPageDocs.ImageIndex = 2;
            this.tabPageDocs.Location = new System.Drawing.Point(4, 44);
            this.tabPageDocs.Name = "tabPageDocs";
            this.tabPageDocs.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageDocs.Size = new System.Drawing.Size(792, 402);
            this.tabPageDocs.TabIndex = 2;
            this.tabPageDocs.Text = "Документи";
            this.tabPageDocs.UseVisualStyleBackColor = true;
            // 
            // tabPageNewTasks
            // 
            this.tabPageNewTasks.ImageIndex = 7;
            this.tabPageNewTasks.Location = new System.Drawing.Point(4, 44);
            this.tabPageNewTasks.Name = "tabPageNewTasks";
            this.tabPageNewTasks.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageNewTasks.Size = new System.Drawing.Size(792, 402);
            this.tabPageNewTasks.TabIndex = 1;
            this.tabPageNewTasks.Text = "Нови задачи";
            this.tabPageNewTasks.UseVisualStyleBackColor = true;
            // 
            // tabPageTasks
            // 
            this.tabPageTasks.ImageIndex = 1;
            this.tabPageTasks.Location = new System.Drawing.Point(4, 84);
            this.tabPageTasks.Name = "tabPageTasks";
            this.tabPageTasks.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageTasks.Size = new System.Drawing.Size(792, 362);
            this.tabPageTasks.TabIndex = 0;
            this.tabPageTasks.Text = "Задачи";
            this.tabPageTasks.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPageTasks);
            this.tabControl1.Controls.Add(this.tabPageNewTasks);
            this.tabControl1.Controls.Add(this.tabPageDocs);
            this.tabControl1.Controls.Add(this.tabPageDocsOK);
            this.tabControl1.Controls.Add(this.tabPageNotes);
            this.tabControl1.Controls.Add(this.tabPageFolders);
            this.tabControl1.Controls.Add(this.tabPageBrowsers);
            this.tabControl1.Controls.Add(this.tabPageQuestions);
            this.tabControl1.Controls.Add(this.tabPageApplications);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ImageList = this.imageList1;
            this.tabControl1.ItemSize = new System.Drawing.Size(58, 40);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.TabPage tabPageApplications;
        private System.Windows.Forms.TabPage tabPageQuestions;
        private System.Windows.Forms.TabPage tabPageBrowsers;
        private System.Windows.Forms.TabPage tabPageFolders;
        private System.Windows.Forms.TabPage tabPageNotes;
        private System.Windows.Forms.TabPage tabPageDocsOK;
        private System.Windows.Forms.TabPage tabPageDocs;
        private System.Windows.Forms.TabPage tabPageNewTasks;
        private System.Windows.Forms.TabPage tabPageTasks;
        private System.Windows.Forms.TabControl tabControl1;
    }
}

